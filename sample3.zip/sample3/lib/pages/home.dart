import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        title:const Text("My Portfolio",style:TextStyle(
        fontWeight:FontWeight.bold,
        fontSize:32,
        color:Colors.black

       ),),
    ),
    body:Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children :[
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Hi I am Sajid",
                style: TextStyle(
                  fontSize:40,
                  fontWeight:FontWeight.bold
                )
              ),
              const SizedBox(),
              Text(
                "I am from SRM ",
                style: TextStyle(
                  fontSize : 25,
                  color: Colors.grey
                ),
              ),
              const SizedBox(),
              TextButton(
                onPressed: () {
                  print("Hello World");
                  Navigator.pushNamed(context,'/about');
                },
                child:Text("About Me",style:TextStyle(color:Colors.black,fontWeight:FontWeight.bold)),
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(Colors.lightBlueAccent),

                ),

              )
            ],
          ),
          const SizedBox(width:45,),
          Hero(
            tag: 'photo',
            child: Container(
              height: 300,
              width: 300,
              decoration: BoxDecoration(
                shape : BoxShape.circle,
                image: DecorationImage(
                  image: AssetImage("Assets/IMG_1795 (1).jpg")
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blueGrey,
                    offset: Offset(0, 0),
                    blurRadius: 3,
                    spreadRadius: 3
                  )
                ]
              )
            ),
          )
        ],
      ),
    ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton:Container(
        height: 50,
        width: 300,
        decoration:BoxDecoration(
          color:Colors.grey,
          borderRadius: BorderRadius.circular(70),
            boxShadow: [
             BoxShadow(
            color: Colors.blueGrey,
            offset: Offset(0, 0),
            blurRadius: 3,
            spreadRadius: 3
        )
          ]
        ),

        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            InkWell(
              onTap: () async {
                await launchUrl(Uri.parse("https://github.com/mohdsajid0506"));
                },

              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Image.asset('Assets/email.png'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Image.asset('Assets/github.png'),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Image.asset('Assets/instagram.png'),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Image.asset('Assets/linkedin.png'),
            ),
          ]
        ),
      )
    );


  }
}
